# 访问数据库根据编号查找经纬度
class Location:
    @staticmethod
    def findByType(category_id):
        # 引入 ImageCategory 模型
        from model.models import ImageCategory as CategoryModel
        return CategoryModel.query.filter_by(id=category_id).first()

